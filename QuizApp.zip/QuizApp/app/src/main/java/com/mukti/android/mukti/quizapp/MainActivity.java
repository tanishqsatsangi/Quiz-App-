package com.mukti.android.mukti.quizapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    int score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    //The submitfunc contains the grading logic it check for all the quiz correct
// answer and updates the score accordingly.Only the correct options ,checkbox and text have been cnsidered.
    public void submitfunc(View view) {
        RadioButton q1answerbtn = (RadioButton) findViewById(R.id.q1option4);
        RadioButton q2answerbtn = (RadioButton) findViewById(R.id.q2option1);
        RadioButton q3answerbtn = (RadioButton) findViewById(R.id.q3option2);
        RadioButton q6answerbtn = (RadioButton) findViewById(R.id.q6option1);
        RadioButton q7answerbtn = (RadioButton) findViewById(R.id.q7option1);
        RadioButton q8answerbtn = (RadioButton) findViewById(R.id.q8option4);
        CheckBox q4answer1 = (CheckBox) findViewById(R.id.q4option1);
        CheckBox q4answer2 = (CheckBox) findViewById(R.id.q4option2);
        CheckBox q4answer3 = (CheckBox) findViewById(R.id.q4option3);
        CheckBox q4answer4 = (CheckBox) findViewById(R.id.q4option4);
        CheckBox q5answer1 = (CheckBox) findViewById(R.id.q5option1);
        CheckBox q5answer2 = (CheckBox) findViewById(R.id.q5option2);
        CheckBox q5answer3 = (CheckBox) findViewById(R.id.q5option3);
        CheckBox q5answer4 = (CheckBox) findViewById(R.id.q5option4);
        EditText q9editext = (EditText) findViewById(R.id.answertextq9);
        EditText q10editext = (EditText) findViewById(R.id.answertextq10);

        if (q1answerbtn.isChecked()) {
            score++;
        }
        if (q2answerbtn.isChecked()) {
            score++;
        }

        if (q3answerbtn.isChecked()) {
            score++;
        }
        if (q4answer1.isChecked() && q4answer2.isChecked() && !q4answer3.isChecked()  && !q4answer4.isChecked()) {
            score++;
        }
        if (q5answer1.isChecked() && q5answer2.isChecked() && q5answer3.isChecked() && !q5answer4.isChecked()) {
            score++;
        }

        if (q6answerbtn.isChecked()) {
            score++;
        }
        if (q7answerbtn.isChecked()) {
            score++;
        }
        if (q8answerbtn.isChecked()) {
            score++;
        }
        String q9answer = q9editext.getText().toString();
        String q10answer = q10editext.getText().toString();
        if (q9answer.equals("")) {
            Toast.makeText(this, "Question 9 not answered", Toast.LENGTH_SHORT).show();
        } else {
            if (q9answer.equals("void")) {
                score++;
            }
        }

        if (q10answer.equals("")) {
            Toast.makeText(getApplicationContext(), "Question 10 not answered", Toast.LENGTH_SHORT).show();
        } else {
            if (q10answer.equals("strings.xml")) {
                score++;
            }
        }
        Toast.makeText(this, "Score: " + score, Toast.LENGTH_SHORT).show();
        score = 0;
    }
}
/*
All the mcqs answers
mcq source-https://www.onlineinterviewquestions.com/android-mcq/
q1-d
q2-a
q3-b 2005
q4-java and kotlin
q5-onCreate(),OnStart(),onResume()
q6-a jellyBean
q7-a oncreateoptionmenu
q8-d mainifest
q9-void
q10-strings.xml
*/